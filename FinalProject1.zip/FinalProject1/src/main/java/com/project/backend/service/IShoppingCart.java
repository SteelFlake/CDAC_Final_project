package com.project.backend.service;

public interface IShoppingCart {

}
